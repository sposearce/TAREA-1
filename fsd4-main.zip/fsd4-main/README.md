# prueba de git
esto es una prueba
uno dos y tres 
prueba de clonar repositorio
ok repositorio clonado
paso dos, subir a repositorio cambios
verificar ok
ctrl l limpia pantalla de terminal
comandos:
"git clone" y copiat http de git hub, si esta bien hecho deberi clonar en terminar o en VSC el repositorio y su contenido
"git status": muestra el estado de los archivos de nuestro proyecto, si son nuevos / esperan ser confirmados * si estan rojo queiere decir que no estan dentro del git a espera de ser confirmados y hay que hacer Git add .
"git add ."
"git commit -m" confirma o acepta cambios que esta en rojo. al poner " -m" espera un mensaje de confirmacion para decir que hiciste "buena practica" ejemplo "" git commit -m "primer commit" "
por ultimo para subir el cambio hacemos git push

tuve un problema pq hice git commit solo y tiro un error que luego no me dejaba hacer git commit -m "". tuve que borrar el archivo index.lock de mi carpeta.

otro comando "git pull", para bajar lo que se hizo/ modifico en git hub en la pagina..